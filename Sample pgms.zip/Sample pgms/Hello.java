class Greet
{
public static void main()
{
        String firstName="Chamu";
        System.out.println("Welcome to Capgemini"+firstName);
}
}