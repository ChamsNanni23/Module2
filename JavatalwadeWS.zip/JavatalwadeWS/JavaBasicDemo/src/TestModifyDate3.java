import java.util.Scanner;

public class TestModifyDate3
{
      public static void main(String[] args) 
      {
    	Scanner sc=new Scanner(System.in);
    	Date allDojs[]=new Date[3];
    	String name[]=new String[3];
    	int day=0,mon=0,year=0;
    	
    	for(int i=0;i<allDojs.length;i++)
    	{
    		System.out.println("Enter your Name: ");
    		name[i]=sc.next();
    		System.out.println("Enter Day: ");
    		day=sc.nextInt();
    		System.out.println("Enter month of joining: ");
    		mon=sc.nextInt();
    		System.out.println("Enter year of joining: ");
    		year=sc.nextInt();
    		
    		allDojs[i]=new Date(day,mon,year);
    	}
    	
    	for(int j=0;j<allDojs.length;j++)
    	{
    		System.out.println(name[j]+"DOJ : "+allDojs[j].dispDate());
    	}
   }

}
