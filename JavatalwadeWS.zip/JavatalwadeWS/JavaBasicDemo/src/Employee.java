
public class Employee
{

	private int empid;
	private String empname;
	private float empsal;
	private char gender;
	
	public Employee()
	{
		empid=101;
		empname="Chamu";
		empsal=15000;
		gender='F';
	}
	
	public Employee(int id,String name,float sal,char gen)
	{
		empid=id;
		empname=name;
		empsal=sal;
		gender=gen;
	}
	
	
	public String dispDetails()
	{
		return (empid+","+empname+","+empsal+","+gender);
	}
	
	public float calcBasicSal()
	{
		return empsal;
	}
}
