public class TestDateDemo
{
      public static void main(String[] args) 
      {
		Date chamuDOJ=new Date(13, 12, 2017);
        System.out.println("Chamu DOJ is:"+chamuDOJ.dispDate());
        
        Date chamsDOJ=new Date(13,11,2017);
        System.out.println("Chams DOJ is:"+chamsDOJ.dispDate());
        
        Date unknownPerson=new Date();
        System.out.println("Unknown Person DOJ is:"+ unknownPerson.dispDate());
	}

}
