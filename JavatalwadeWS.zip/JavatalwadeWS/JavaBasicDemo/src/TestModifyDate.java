import java.util.Scanner;

public class TestModifyDate
{
      public static void main(String[] args) 
      {
    	Scanner sc=new Scanner(System.in);
    	
		System.out.println("Enter Day :");
		int dayOfDoj=sc.nextInt();
		

		System.out.println("Enter Month :");
		int monOfDoj=sc.nextInt();
		

		System.out.println("Enter Year :");
		int yearOfDoj=sc.nextInt();
		
		Date chamuDOJ=new Date(dayOfDoj,monOfDoj,yearOfDoj);
        System.out.println("Your DOJ is:"+chamuDOJ.dispDate());
        
       }

}
