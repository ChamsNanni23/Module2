
public class TestEmployee {

	public static void main(String[] args)
	{
		Employee e1=new Employee(142311,"Chamu",1000.0F,'F');
		System.out.println("Employee details :"+e1.dispDetails());
		
		Employee e2=new Employee(129684,"Nanni",6000.0F,'F');
		System.out.println("Employee details :"+e2.dispDetails());
		

	}

}
