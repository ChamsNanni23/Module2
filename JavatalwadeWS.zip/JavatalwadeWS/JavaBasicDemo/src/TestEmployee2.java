import java.util.Scanner;

public class TestEmployee2 {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		Employee employees[]=new Employee[3];
		int empid=0;
		String empname="null";
		char gender=' ';
		float empsal=0.0F;
		String empgen="null";
		
		
		for(int i=0;i<employees.length;i++)
    	{
			System.out.println("Enter your ID: ");
    		empid=sc.nextInt();
    		System.out.println("Enter your Name: ");
    		empname=sc.next();
    		System.out.println("Enter your Salary: ");
    		empsal=sc.nextFloat();
    		System.out.println("Enter your Gender: ");
    		empgen=sc.next();
    		gender=empgen.charAt(0);
    		
    		employees[i]=new Employee(empid,empname,empsal,gender);
    	}
		 
		for(int j=0;j<employees.length;j++)
		{
			System.out.println("Employee details are :"+employees[j].dispDetails());
		}
		
		

	}

}

