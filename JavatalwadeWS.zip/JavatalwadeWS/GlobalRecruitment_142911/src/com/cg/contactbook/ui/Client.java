package com.cg.contactbook.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.service.ContactBookService;
import com.cg.contactbook.service.ContactBookServiceImpl;


public class Client
{
	  static Scanner sc=null;
	  static ContactBookService conbookser=null;
    public static void main(String[] args)
	{
       conbookser=new ContactBookServiceImpl();
   	   sc=new Scanner(System.in);
   	 int choice=0;
   	 while(true)
   	 {
   		 System.out.println("************Global Recruitments************");
   		 System.out.println("Choose an operation");
   		 System.out.println("1.Enter Enquiry Details\n"
   				 + "2.View Enquiry Details on Id\n"
   				 + "0.Exit");
   		 choice=sc.nextInt();
   		 switch(choice)
		 {
		 case 1:addEnquiry();
		        break;
		 case 2:getEnquiryDetails();
		        break;
		 case 0:System.out.println("Thank You!");
		        break;
		 }
     }
	}
/*********Main ends here***************/
    
    public static void addEnquiry() 
    {
		EnquiryBean enqry=new EnquiryBean();
		String fName=null;
		String lName=null;
		String contactNo=null;
		String pLocation=null;
		String pDomain=null;
    try
    {
		System.out.println("Enter First Name: ");
		enqry.setfName(sc.next());
		System.out.println("Enter Last name: ");
		enqry.setlName(sc.next());
		System.out.println("Enter Contact no: ");
		enqry.setContactNo(sc.next());
		System.out.println("Enter Preferred Location: ");
		enqry.setpLocation(sc.next());
		System.out.println("Enter Preferred Domain: ");
		enqry.setpDomain(sc.next());
		enqry.setfName(fName);
		enqry.setlName(lName);
		enqry.setContactNo(contactNo);
		enqry.setpLocation(pLocation);
		enqry.setpDomain(pDomain);
		int dataAdded=conbookser.addEnquiry(enqry);
		if(dataAdded==1)
		 {
			 System.out.println("Data added");
		 }
		 else
		 {
			 System.out.println("May be some exception"
					 + "while addition");
		 }
    }
	 catch(Exception  e)
	 {
		 System.out.println(e.getMessage());
	 }		 
}
    
/***********************************/
    
   public static void getEnquiryDetails() 
   {

		try 
		{
			ArrayList<EnquiryBean> enqList = conbookser.getEnquiryDetails();

			for(EnquiryBean en:enqList)
			{
				System.out.println(en);
			}
		} 
		catch (ContactBookException e)
		{
			System.out.println("Some exception while fetching data");
			e.printStackTrace();
		}

	}
}