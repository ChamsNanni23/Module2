package com.cg.contactbook.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;
import com.cg.contactbook.util.DBUtil;
public class ContactBookDaoImpl  implements ContactBookDao
{
	
	private int enqryId = 0;
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    Logger conLogger=null;
    
    public void ContactBookImpl()
    {
    	PropertyConfigurator.
    	configure("resources/log4j.properties");
    	conLogger=Logger.getLogger("EmpDaoImpl.class");
    }

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		String insertQry="INSERT INTO enquiry(enqryId,firstName,lastName,contactNo,domain,city) VALUES(?,?,?,?,?,?)";
		int dataAdded = 0;
		try {
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, getEnqryId());
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setString(4, enqry.getContactNo());
			pst.setString(5, enqry.getpDomain());
			pst.setString(6, enqry.getpLocation());
			System.out.println("***********");
			dataAdded=pst.executeUpdate();
			conLogger.log(Level.INFO, 
					"Data Inserted: "+enqry);
		} 
		catch (Exception  e) 
		{
			conLogger.error("This is exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				throw new ContactBookException(e.getMessage());
			}
		}
		return dataAdded;
	}
		
	private int getEnqryId() 
	{
		String qry="SELECT enquiries.NEXTVAL" + " FROM DUAL ";
		int generatedVal = 0;
		try
		{
		   con=DBUtil.getCon();
		   st=con.createStatement();
		   rs=st.executeQuery(qry);
		   rs.next();
		   generatedVal=rs.getInt(1);
		   
	    }
		catch(Exception e)
		{
			try 
			{
				conLogger.error("This is exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			} 
			catch (ContactBookException e1)
			{
			   e1.printStackTrace();
			}
		}
		finally
		{
			try {
				rs.close();
				st.close();
				
				con.close();
			    } 
			catch (SQLException e)
			{
				try {
					throw new ContactBookException(e.getMessage());
				} 
			catch (ContactBookException e1)
				{
					e1.printStackTrace();
				}
			}
		}
	    return  generatedVal;
	}

   public ArrayList<EnquiryBean> getEnquiryDetails() throws ContactBookException
	{
		ArrayList<EnquiryBean> enqList=new ArrayList<EnquiryBean>();
		String selectQry="SELECT * FROM enquiry";
		EnquiryBean enqry=null;
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				enqry=new EnquiryBean(rs.getInt("enqryId"),
						        rs.getString("firstName"),
						        rs.getString("lastName"),
						        rs.getString("contactNo"),
						        rs.getString("domain"),
						        rs.getString("city"));
				enqList.add(enqry);
			}
		}
		catch (Exception e) 
		{
			conLogger.error("This is Exception:"+e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try {
				rs.close();
				st.close();
				con.close();
			    } 
			catch (SQLException e)
			{
				conLogger.error("This is Exception:"+e.getMessage());
				throw new ContactBookException(e.getMessage());
			}
		}
		return enqList;
	}
}
