package com.cg.contactbook.junit;
import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;


public class ContactBookDaoImplTest
{
	static ContactBookDao conbookDao=null;
	static EnquiryBean enqry=null;
	@BeforeClass
	public static void beforeClass() throws ContactBookException
	{
		conbookDao=new ContactBookDaoImpl();
		enqry=new EnquiryBean();
	}
	
	@Test
	public void testaddEnquiry1() throws ContactBookException
	{
		Assert.assertEquals(1, conbookDao.addEnquiry(enqry));
	}
	
	@Test(expected=Exception.class)
	public void testaddEnquiry2() throws ContactBookException
	{
		Assert.assertEquals(1, conbookDao.addEnquiry(enqry));
	}
	
	@Test
	public void testAddEmp3() throws ContactBookException
	{
		Assert.assertNotNull(conbookDao.getEnquiryDetails());
	}
	

}
