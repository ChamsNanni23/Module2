package com.cg.contactbook.service;

import java.util.ArrayList;
import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookException;


public interface ContactBookService 
{
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;
	public  ArrayList<EnquiryBean> getEnquiryDetails() throws ContactBookException;
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException;
	public boolean validateContactNo(String contactNo) throws ContactBookException;
	public boolean validateFirstName(String fName) throws ContactBookException;
}
