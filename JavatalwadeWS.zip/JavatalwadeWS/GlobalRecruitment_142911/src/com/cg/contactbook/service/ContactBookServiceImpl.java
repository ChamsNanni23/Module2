package com.cg.contactbook.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.dao.ContactBookDao;
import com.cg.contactbook.dao.ContactBookDaoImpl;
import com.cg.contactbook.exception.ContactBookException;



public class ContactBookServiceImpl implements ContactBookService
{
	ContactBookDao conbookDao=null;
	public ContactBookServiceImpl()
	{
		conbookDao = new ContactBookDaoImpl();
	}


	@Override
	public boolean isValidEnquiry(EnquiryBean enqry)
			throws ContactBookException
	{
		return false;
	}
	
	public boolean validateFirstName(String fName) {
		Pattern namePattern = Pattern.compile(
				"[A-Z]{1}[a-zA-Z\\s]{3,25}");
		Matcher nameMatcher = namePattern.matcher(fName);
		return nameMatcher.matches();
	}
	
	public boolean validateContactNo(String contactNo) {
		Pattern mobilePattern = Pattern.compile("[1-9]{1}[0-9]{9}");
		Matcher mobileMatcher = mobilePattern.matcher(contactNo);
		return mobileMatcher.matches();
	}

	
	public boolean isValidPLocation(String pLocation){
		if(pLocation!=null)
		{
			return true;
		}
		else
			return false;
		}
	
 
	public boolean isValidPDomain(String pDomain){
		if(pDomain!=null)
		{
			return true;
		}
		else
			return false;
		}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		return conbookDao.addEnquiry(enqry);
	}


	@Override
	public ArrayList<EnquiryBean> getEnquiryDetails()
			throws ContactBookException {
		return conbookDao.getEnquiryDetails();
	}
}
