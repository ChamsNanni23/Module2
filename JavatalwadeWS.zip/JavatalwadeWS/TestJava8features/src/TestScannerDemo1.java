@FunctionalInterface
interface MaxFinder
{
	public int max(int num1,int num2);
}
