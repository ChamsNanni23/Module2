import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

@FunctionalInterface
interface MaxFiner
{
	public int max(int num1,int num2);
}
public class TestScannerDemo
{
	public static void main(String[] args)
	{
      Consumer<String> consumer=
    		  (String str)->
      System.out.println(str);
      consumer.accept("Welcome");
      Supplier<String> sup=()->"Happy new year";
      System.out.println(sup.get());
      BiFunction<Integer,Integer,Integer>
      bifunctiona=(x,y)->x>y?x:y;
      System.out.println("Greatest  number is:"+bifunctiona.apply(90,80));
      Predicate<Integer> predicate=(num)->num%2==0;
      System.out.println("Is 4 even no?"+predicate.test(4));
      System.out.println("Is 3 even no?"+predicate.test(3));
	}
}
      