public class TestPerson2 {

	public static void main(String[] args)
	{
		Person2 p1=new Person2("Chamu","CBHGT6789",23);
		Person2 p2=new Person2("Nanni","C6HGT6789",23);
		Person2 p3=new Person2("Chamu","CBHGT6789",23);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		Integer i1=new Integer(20);
		Integer i2=new Integer(20);
		Integer i3=new Integer(40);
		
		System.out.println("i1="+i1);
		System.out.println("i2="+i2);
		System.out.println("i3="+i3);
		
		if(i1.equals(i2))
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Different");
		}
		System.out.println("Hashcode of p1 "+p1.hashCode());
		System.out.println("Hashcode of p2 "+p2.hashCode());
		System.out.println("Hashcode of p3 "+p3.hashCode());
		
		System.out.println("Hashcode of i1 "+i1.hashCode());
		System.out.println("Hashcode of i2 "+i2.hashCode());
		System.out.println("Hashcode of i3 "+i3.hashCode());
		}
}
