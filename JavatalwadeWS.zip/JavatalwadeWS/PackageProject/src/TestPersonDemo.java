public class TestPersonDemo {

	public static void main(String[] args)
	{
		Person p1=new Person("Chamu","CBHGT6789",23);
		Person p2=new Person("Nanni","C6HGT6789",23);
		Person p3=new Person("Chamu","CBHGT6789",23);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		if(p1.equals(p3))
		{
			System.out.println("Same");
		}
		else
		{
			System.out.println("Not same");
		}
		
		
	}

}
