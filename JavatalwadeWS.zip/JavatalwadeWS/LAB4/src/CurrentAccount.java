//4.2 Current account
public class CurrentAccount extends Account
{
    private double  overdraftLimit=2000;
    
    public CurrentAccount()
    {
    	super();
    }
    
     public CurrentAccount(Person accHolder,long accNum,double balance)
     {
		super(accHolder,accNum,balance);
     }

    public boolean withdraw(double amt)
		{
			if(amt<=overdraftLimit)
			super.withdraw(amt);
			else
			{
				System.out.println("Minimum balance is required");
			}
			return false;
		}
}


