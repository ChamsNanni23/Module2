//4.1 Account class

public class Account
{
	   private long accNum;
	   private double balance;
	   private Person accHolder;
	   private  static double  minbal = 500.0;
	   
	public Account(Person accHolder, long accNum, double balance) {
		
	}
	public Account() {
		
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public static double getMinbal() {
		return minbal;
	}
	public static void setMinbal(double minbal) {
		Account.minbal = minbal;
	}
	public boolean deposit(double amt)
	{
		this.balance=this.balance+amt;
		return true;
	}
	public boolean withdraw(double amt)
	{
		if((this.balance>amt)&&(this.balance-amt)>minbal)
		{
			this.balance=this.balance-amt;
			return true;
		}
		else
		{
			System.out.println("No Sufficient balance");
			return false;
		}
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
}   

