//4.2 Savings account
public class SavingsAccount extends Account 
{
		private static  int minbal=500;
		private double balance;

		public void setMinbal(int minbal) {
			this.minbal = minbal;
		}
		public boolean withdraw(double amt)
		{
			if(this.balance>minbal)
			{
				this.balance=this.balance-amt;
				return true;
			}
			else
			{
				System.out.println("Minimum balance is required");
				return false;
			}
		}
}


