//4.1 Main class
import java.util.Random;
public class TestPerson
{
	public static void main(String[] args)
	{
		long Accnum;
		Person p1=new Person();
		p1.setName("Smith");
		p1.setAge(24);
		
		Accnum=new Random().nextLong();
		Account Smith=new Account();
		Smith.setAccHolder(p1);
		Smith.setBalance(2000);
		Smith.setAccNum(Accnum);
		
		Person p2=new Person();
		p2.setName("Kathy");
		p2.setAge(24);
		
		Accnum=new Random().nextLong();
		Account Kathy=new Account();
		Kathy.setAccHolder(p1);
		Kathy.setBalance(3000);
		Kathy.setAccNum(Accnum);
		
		Kathy.withdraw(2000);
		Smith.deposit(2000);
		
		System.out.println("Updated balance of smith: "+Smith.getBalance());
		System.out.println("Updated balance of kathy: "+Kathy.getBalance());
		
		System.out.println(Smith);
		System.out.println(Kathy);
		
		
	}

}
