package com.cg.empmgm.exception;

public class EmployeeException extends Exception 
{
	public  EmployeeException(String msg)
	{
		super(msg);
	}

}
