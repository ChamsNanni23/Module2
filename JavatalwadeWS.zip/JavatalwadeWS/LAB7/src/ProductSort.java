//7.1
import java.util.*;
public  class ProductSort
{
   public static void main(String[] args) 
    {
         String products[] = { "Haircare", "Beauty", "Household", "Groceries" };
         System.out.println("The original order:");
         for (int i = 0; i < products.length; i++)
         System.out.println(i + ": " + products [i]);
         Arrays.sort(products);
         System.out.println("The new order:");
         for (int i = 0; i < products.length; i++)
         System.out.println(i + ": " +products[i]);
  }
   
 }