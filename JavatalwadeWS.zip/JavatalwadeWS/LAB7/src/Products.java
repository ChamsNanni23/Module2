public class Products 
{
	private String productName;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Products(String productName) {
		super();
		this.productName = productName;
	}

	@Override
	public String toString() {
		return "Products [productName=" + productName + "]";
	}
	

}
