public class Medicine 
{
	private String medname;
	private String compName;
	private float price;
	private String expdate;
	
    public Medicine(){
		
	};

	public Medicine(String medname, String compName, float price, String expdate) {
		this.medname = medname;
		this.compName = compName;
		this.price = price;
		this.expdate = expdate;
	}

	
	public String dispMedInfo() {
		return "Medicine [medname=" + medname + ", compName=" + compName
				+ ", price=" + price + ", expdate=" + expdate + "]";
	};
	
}
