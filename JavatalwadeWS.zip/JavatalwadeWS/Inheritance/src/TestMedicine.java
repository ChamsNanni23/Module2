import java.util.Scanner;

public class TestMedicine
{
    public static void main(String[] args)
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("How many medicine?");
    	int medCount=sc.nextInt();
    	Medicine medArr[]=new Medicine[medCount];
    	String medname=null;
    	String compName=null;
    	float price=0.0F; 
    	String expdate=null;
    	for(int i=0;i<medArr.length;i++)
    		{
    		System.out.println("Enter medicine name: ");
    		medname=sc.next();
    		System.out.println("Enter company name: ");
    		compName=sc.next();
    		System.out.println("Enter price: ");
    		price=sc.nextFloat();
    		System.out.println("Enter expiry date: ");
    		expdate=sc.next();
    		
    		System.out.println("What type of medicine " +medname+ "is?"+ "1.Tablet\t2.Ointment\t3.Syrup");
    		System.out.println("Enter Choice:");
    		int choice=sc.nextInt();
    		switch(choice)
    		{
    		case 1:medArr[i]=new Tablet(medname,compName,price,expdate);
    		       break;
    		case 2:medArr[i]=new Ointment(medname,compName,price,expdate);
    		       break;
    		case 3:medArr[i]=new Syrup(medname,compName,price,expdate);
    		       break;
    		default:
    			medArr[i]=new Tablet(medname,compName,price,expdate);
    			break;
    		}
    	}
    	System.out.println("******************");
    	for(int j=0;j<medArr.length;j++)
    	{
    		if(medArr[j] instanceof Syrup)
    		{
    			System.out.println("\nSyrup: "+medArr[j].dispMedInfo());
    		}
    		else if(medArr[j] instanceof Ointment)
    		{
    			System.out.println("\nOintment: "+medArr[j].dispMedInfo());
    		}
    		else
    		{
    			System.out.println("Tablet: "+medArr[j].dispMedInfo());
    		}
    		}
    	}
    }

