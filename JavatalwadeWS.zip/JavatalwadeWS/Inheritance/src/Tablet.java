public class Tablet extends Medicine {
	public Tablet()
	{
		super();
	}
	public Tablet(String medname,String compName,float price,String expdate)
	{
		super(medname,compName,price,expdate);
	}
	public String dispMedInfo() {
		return super.dispMedInfo() +"\nStore in a cool and dry place";
	}

}

