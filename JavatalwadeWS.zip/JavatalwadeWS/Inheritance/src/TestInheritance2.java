import java.util.Scanner;

public class TestInheritance2
{
    public static void main(String[] args)
    {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("How many employee?");
    	int empCount=sc.nextInt();
    	Employee empArr[]=new Employee[empCount];
    	int eId=0;
    	String enm=null;
    	int noOfHrs=0;
    	int rateperHrs=0;
    	float esl=0.0F;
    	for(int i=0;i<empArr.length;i++)
    		{
    		System.out.println("Enter emp Id: ");
    		eId=sc.nextInt();
    		System.out.println("Enter emp name: ");
    		enm=sc.next();
    		System.out.println("Enter emp salary: ");
    		esl=sc.nextFloat();
    		System.out.println("What type of emp " +enm+ "is?"+ "1.Emp\t2.WageEmp\t3.SalesManager");
    		System.out.println("Enter Choice:");
    		int choice=sc.nextInt();
    		switch(choice)
    		{
    		case 1:empArr[i]=new Employee(eId,enm,esl);
    		       break;
    		case 2:System.out.println("Enter No of Hrs u worked");
    		       noOfHrs=sc.nextInt();
    		       System.out.println("Enter rate per hour");
    		       rateperHrs=sc.nextInt();
    		       empArr[i]=new WageEmp(eId,enm,esl,noOfHrs,rateperHrs);
    		       break;
    		default:
    			System.out.println("Enter no of hours u worked");
    			noOfHrs=sc.nextInt();
    			System.out.println("Enter rate per hour");
    			rateperHrs=sc.nextInt();
    			System.out.println("Enter sales u have done");
    			int sale=sc.nextInt();
    			System.out.println("Enter commission:");
    			int comm=sc.nextInt();
    			empArr[i]=new SalesManager(eId,enm,esl,noOfHrs,rateperHrs,comm,sale);
    		}
    	}
    	System.out.println("******************");
    	for(int j=0;j<empArr.length;j++)
    	{
    		if(empArr[j] instanceof SalesManager)
    		{
    			System.out.println("SalesMgr: "+empArr[j].dispEmpInfo()+"Monthly Basic sal: "+empArr[j].calcEmpBasicSal()+"Annual Sal:"+empArr[j].calcEmpAnnualSal());
    		}
    		else if(empArr[j] instanceof WageEmp)
    		{
    			System.out.println("Wage Emp: "+empArr[j].dispEmpInfo()+"Monthly Basic sal: "+empArr[j].calcEmpBasicSal()+"Annual Sal:"+empArr[j].calcEmpAnnualSal());
    		}
    		else
    		{
    			System.out.println("Employee: "+empArr[j].dispEmpInfo()+"Monthly Basic sal: "+empArr[j].calcEmpBasicSal()+"Annual Sal:"+empArr[j].calcEmpAnnualSal());
    		}
    		}
    	}
    }

