public class TestStaticEmpDemo 
{
  public static void main(String[] args)
  {
	  Emp e1=new Emp(111,"Chamu",1500.0F);
	  Emp e2=new Emp(121,"ChamS",1600.0F);
	  Emp e3=new Emp(131,"Nanni",1700.0F);
	  System.out.println(e1.dispEmpInfo());
	  System.out.println(e2.dispEmpInfo());
	  System.out.println(e3.dispEmpInfo());
	  Emp.getCount();
  }
}
