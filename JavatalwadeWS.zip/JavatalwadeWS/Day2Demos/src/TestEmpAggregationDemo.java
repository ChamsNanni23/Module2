import java.util.Scanner;

public class TestEmpAggregationDemo 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter Number of employee: ");
		int n=sc.nextInt();
		Employee employees[]=new Employee[n];
		int empId=0;
		String empName="null";
		float empSal=0.0F;
		    
		    int day=0;
			int mon=0;
			int year=0;
	    
		
		for(int i=0;i<n;i++)
    	{
			System.out.println("Enter your ID: ");
    		empId=sc.nextInt();
    		System.out.println("Enter your Name: ");
    		empName=sc.next();
    		System.out.println("Enter your Salary: ");
    		empSal=sc.nextFloat();
    		System.out.println("Enter your DOJ day: ");
    		day=sc.nextInt();
    		System.out.println("Enter your DOJ month: ");
    		mon=sc.nextInt();
    		System.out.println("Enter your DOJ year: ");
    		year=sc.nextInt();
    		
    		Date DOJ=new Date(day,mon,year);
    		employees[i]=new Employee(empId,empName,empSal,DOJ);
    	}
		 
		for(int j=0;j<n;j++)
		{
			System.out.println("Employee details are :"+employees[j].dispEmpInfo());
		}
		
		
	}

}
