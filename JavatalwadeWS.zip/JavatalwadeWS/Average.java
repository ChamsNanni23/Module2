class  Average
{
   public static void main(String ar[])
   {
      int i,sum=0,average=0;
      for(i=1;i<10;i++)
      {
         sum=Integer.parseInt(ar[i])+sum;
  
         average=sum/10;
      }
         System.out.println("Average is" +average);
    }
}
