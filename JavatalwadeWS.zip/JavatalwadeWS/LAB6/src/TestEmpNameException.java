import java.util.Scanner;

public class TestEmpNameException 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String firstName=null;
		String lastName=null;
		String gender=null;
		
		System.out.println("Enter employee firstname:");
		firstName=sc.next();
		System.out.println("Enter employee lastname:");
		lastName=sc.next();
		System.out.println("Enter employee gender:");
		gender=sc.next();
		
		
		EmployeeNameException emp=new EmployeeNameException(firstName,lastName,gender);
		System.out.println("Employee details are:"+emp.dispPerson1());
		
		if(firstName.compareTo("null")==0 || lastName.compareTo("null")==0)
			{
			try
			{
			throw new Exception("Check firstname and lastname");
		    }
			catch(Exception e)
			{
				System.out.println("Invalid input");
			}
			}
		else
		{
			System.out.println("Valid entry");
		}
	}
		
}
