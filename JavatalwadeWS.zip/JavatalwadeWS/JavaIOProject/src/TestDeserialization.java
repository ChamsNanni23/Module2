import java.io.*;


public class TestDeserialization
{
	public static void main(String[] args)
	{
		ObjectInputStream ois;
		FileInputStream fis;
		try {
				fis=new FileInputStream("EmpData.obj");
				ois=new ObjectInputStream(fis);
				Emp e1=(Emp)ois.readObject();
				System.out.println("Emp object is written in a file"+e1);
			}
		catch (IOException | ClassNotFoundException e) 
		{
		    e.printStackTrace();
	    }
    }
	    
	  
  }
