	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.ObjectOutputStream;
	import java.util.Scanner;


	public class TestSerialization3 {
		public static void main(String[] args)
		{
			
			Scanner sc=new Scanner(System.in);
			System.out.println("How many employees?");
			int count =sc.nextInt() ;
			Emp empl[]=new Emp[count];
			
			for(int i=0;i<count;i++)
			{
				
			System.out.println("Enter emp id:");
		    int empId=sc.nextInt();
			System.out.println("Enter emp name:");
		    String empName=sc.next();
			System.out.println("Enter emp salary:");
		    float empSal=sc.nextFloat();
		    empl[i]=new Emp(empId,empName,empSal);
			}
			FileOutputStream fos;
			ObjectOutputStream oos;
			try {
				fos=new FileOutputStream("EmpData.obj");
				 oos=new ObjectOutputStream(fos);
				for(int j=0;j<count;j++)
				{
					oos.writeObject(empl[j]);
				}
				
				System.out.println("Emp object is written in a file");
			} 
			catch (IOException e) {
				
				e.printStackTrace();
			}
					}
	}




