import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class TestSerialization2 {
	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		Emp empl[]=new Emp[3];
		int empId=0;
		String empName=null;
		float empSal=0.0F;
		
		for(int i=0;i<empl.length;i++)
		{
		System.out.println("Enter emp id:");
	    empId=sc.nextInt();
		System.out.println("Enter emp name:");
	    empName=sc.next();
		System.out.println("Enter emp salary:");
	    empSal=sc.nextFloat();
	    empl[i]=new Emp(empId,empName,empSal);
		}
		FileOutputStream fos;
		ObjectOutputStream oos;
		try {
			fos=new FileOutputStream("EmpData.obj");
			 oos=new ObjectOutputStream(fos);
			for(int j=0;j<empl.length;j++)
			{
				oos.writeObject(empl[j]);
			}
			
			System.out.println("Emp object is written in a file");
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
				}
}

