import java.io.*;
import java.util.Properties;

public class TestPropertyFileDemo {

	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try
		{
		fr=new FileReader("userInfo.properties");
		props=new Properties();
		props.load(fr);
		System.out.println(" *****all data***** ");
		
		    String propValue1=props.getProperty("username");
		    String propValue2=props.getProperty("password");
		    String propValue3=props.getProperty("location");
		    String propValue4=props.getProperty("state");
		    System.out.println("User Name:"+propValue1);
		    System.out.println("Password :"+propValue2);
		    System.out.println("location:"+propValue3);
		    System.out.println("state:"+propValue4);
		
	    }
		catch(IOException e)
		{
			e.printStackTrace();
		}

}
}
