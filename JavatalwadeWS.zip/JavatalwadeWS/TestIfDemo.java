public class TestIfDemo
{
public static void main(String ar[])
{
        int marks=Integer.parseInt(ar[0]);
        if(marks<40)
        {
           System.out.println("you are fail");
        }
        else if((marks>=40)&&(marks<60))
        {
            System.out.println("you are fail");
        }
        else if((marks>=60)&&(marks<75))
        {
            System.out.println("First class");
        }
         else if((marks>=75)&&(marks<100))
        {
            System.out.println("Distinction");
        }
        else
        {
            System.out.println("Not Applicable"); 
        }
}
}
class WishMe
{
public static void main(String ar[])
{
        String firstName="Chamu";
        System.out.println("Happy New year" + firstName);
}
}