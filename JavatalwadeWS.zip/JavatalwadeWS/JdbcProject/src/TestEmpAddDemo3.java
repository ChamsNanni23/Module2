import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestEmpAddDemo3 {
	 public static void main(String[] args) 
	   {
			//Load oracle type 4 driver in memory
		   Connection conn=null;
		   
		   ResultSet rs=null;
		   PreparedStatement ps=null;
		   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String deleteQry="DELETE  FROM  emp_142911 WHERE emp_id=101";
			ps=conn.prepareStatement(deleteQry);
			int data=ps.executeUpdate();
			System.out.println("data deleted in table:"+data);
		       }
			
		   catch (Exception e) 
		   {
			e.printStackTrace();
		   }
	   }

}
