import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpAddDemo4 {
	 public static void main(String[] args) 
	   {
			//Load oracle type 4 driver in memory
		    Scanner sc=new Scanner(System.in);
		    Connection conn=null;
		    System.out.println("Enter Number of employees : ");
		    
		    int n1=sc.nextInt();
		    PreparedStatement pst=null;
		    
			
		   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String insertQry="INSERT INTO emp_142911(emp_id,"
					+ "emp_name,emp_sal)VALUES"
					+"(?,?,?)";
			pst=conn.prepareStatement(insertQry);
			for(int i=0;i<n1;i++)
			{
			System.out.println("Enter id:");
			int empId=sc.nextInt();
			System.out.println("Enter name:");
			String empName=sc.next();
			System.out.println("Enter salary:");
			float empSal=sc.nextFloat();
			
			pst.setInt(1,empId);
			pst.setString(2,empName);
			pst.setFloat(3,empSal);
			
			int dataAdded=pst.executeUpdate();
			
			}
			System.out.println("Data is added....");
		   }
		   catch(Exception e) 
		   {
			e.printStackTrace();
		   }
		   finally
		   {
			   try{
				   pst.close();
				   conn.close();
			   }
			   catch(SQLException e)
			   {
				   e.printStackTrace();
			   }
		   }
	   }
}

