import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class TestEmpMenuDemo 
{
	public static void main(String[] args)
	{
		Connection conn=null;
		   Statement st=null;
		   ResultSet rs=null;
		   String Menu=null;
		   Scanner sc=new Scanner(System.in);
		   PreparedStatement pst=null;
		    
		   try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
				System.out.println("***MENU***\n1.Insert\n2.Update\n3.Delete\n4.Select all\n6.Exit");
				int n=sc.nextInt();
				switch(n)
				{
				case 1:{
					System.out.println("How many employees you want?");
					int n1=sc.nextInt();
					String insertQry="INSERT INTO emp_142911(emp_id,"
							+ "emp_name,emp_sal)VALUES"
							+"(?,?,?)";
					  pst=conn.prepareStatement(insertQry);
				       for(int i=0;i<n1;i++)
				        {
					  System.out.println("Enter id:");
					  int empId=sc.nextInt();
					  System.out.println("Enter name:");
					  String empName=sc.next();
					  System.out.println("Enter salary:");
					  float empSal=sc.nextFloat();
					  
					  pst.setInt(1,empId);
					  pst.setString(2,empName);
					  pst.setFloat(3,empSal);
					  int dataAdded=pst.executeUpdate();
					  
					}
				       System.out.println("Data is added....");
				       break;
				}
				case 2:{
					System.out.println("What you want to update?");
				
				       System.out.println("1.Empname 2.Empsal");
				       int choice= sc.nextInt();
				       switch(choice){
				       case 1:
				       {
				    	   System.out.println("Enter name:");
				    	   String nm=sc.next();
				    	   String updateQry="UPDATE emp_142911 set emp_Name=? WHERE emp_Id=111";
				    	   pst=conn.prepareStatement(updateQry);
				    	   pst.setString(1,nm);
				    	   int dataAdded=pst.executeUpdate();
				    	   System.out.println("Emp name updated");
				    	   break;
				       }
				       case 2:
				       {
				    	   String updateQry="UPDATE emp_142911 set emp_Sal=emp_Sal+10000 WHERE emp_Sal<5000";
				    	   pst=conn.prepareStatement(updateQry);
				    	   pst.executeUpdate();
				    	   System.out.println("Emp salary updated");
				    	   break;
				       }
				       default:
				       {
				    	   System.out.println("wrong choice");
				    	   break;
				       }
				}}
				case 3:{
					   
				       String deleteQry="DELETE  FROM  emp_142911 WHERE emp_id=55";
				       pst=conn.prepareStatement(deleteQry);
				       int data=pst.executeUpdate();
			           System.out.println("data deleted in table:"+data);
			           break;
				}
				case 4:{
					st=conn.createStatement();
				
				       String selQry="SELECT emp_id,emp_name,emp_sal"
			               +" FROM emp_142911";
		              	rs=st.executeQuery(selQry);
			            
			            System.out.println("ID\t NAME\t SALARY");
			            while(rs.next())
			            {
		             	System.out.println(rs.getInt(1)+
				               	"\t "+rs.getString("emp_name")+
				                	"\t "+rs.getInt("emp_sal"));
			            }
			            break;
				}
				default:{
					System.out.println("exit");
				
				        break;
				}
		   }
	}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
		  
	}
	
}


