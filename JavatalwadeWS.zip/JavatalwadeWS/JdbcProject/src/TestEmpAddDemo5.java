import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestEmpAddDemo5 {
	 public static void main(String[] args) 
	   {
			//Load oracle type 4 driver in memory
		   Connection conn=null;
		   
		   ResultSet rs=null;
		   PreparedStatement ps=null;
		   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String updateQry="UPDATE  emp_142911  SET emp_sal=emp_sal+10000 WHERE emp_sal=6000";
			ps=conn.prepareStatement(updateQry);
			int data=ps.executeUpdate();
			System.out.println("data deleted in table:"+data);
		       }
			
		   catch (Exception e) 
		   {
			e.printStackTrace();
		   }
	   }

}
