import java.util.*;
public class TestEmpArrayListDemo 
{
   public static void main(String[] args) 
   {
	   ArrayList<Emp> empList=new  ArrayList<Emp>();
	   
	   Emp e1=new Emp(111,"Chamu",4000.0F);
	   Emp e2=new Emp(222,"Nanni",5250.0F);
	   Emp e3=new Emp(333,"Devaki",90000.0F);
	   
	   empList.add(e1);
	   empList.add(e2);
	   empList.add(e3);
	   System.out.println("****Print without iterator****");
	   System.out.println(empList);
	   
	   System.out.println("****Print with iterator****");
	   Iterator<Emp> empListIt=empList.iterator();
	   while(empListIt.hasNext())
	   {
		   Emp tempEmp=empListIt.next();
		   System.out.println(" ID : "+tempEmp.getEmpId());
		   System.out.println(" Name : "+tempEmp.getEmpName());
		   System.out.println(" SALARY : "+tempEmp.getEmpSal());
		   System.out.println("------------------");
	   }
	   
	   

	}

}
