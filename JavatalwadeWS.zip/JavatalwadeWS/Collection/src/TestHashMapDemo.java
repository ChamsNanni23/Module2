import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class TestHashMapDemo 
{
	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(7386717609L, "Chams");
		mobileDirectory.put(7386717649L, "Poha");
		mobileDirectory.put(7386717609L, "ooha");
		
		Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		
		Iterator<Entry<Long,String>> mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry=mobIt.next();
			System.out.println("Mobile: "+dirEntry.getKey()+"Name:"+dirEntry.getValue());
		}
		}

}
