class Factorial
{
    public static void main(String ar[]) 
    {
     int number=Integer.parseInt(ar[0]);
     int i,fact=1;
     for(i=1;i<=number;i++){
     fact=fact*i;
     }
       System.out.println("Factorial of" +fact);
}
}
