package com.cg.eis.pl;
import com.cg.eis.*;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

import java.util.Scanner;

public class MainClass 
{
    public static void main(String[] args) 
    {
    	
    	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:");
		int empId=sc.nextInt();
		System.out.println("Enter employee name:");
		String empName=sc.next();
		System.out.println("Enter employee salary:");
		float empSal=sc.nextFloat();
		System.out.println("Enter designation");
		String designation=sc.next();
		
		Service s=new Service(empSal,designation);
		String insuranceScheme = s.insuranceScheme();
		Employee e=new Employee(empId,empName,empSal,designation,insuranceScheme);
		System.out.println("Details are:"+e.toString());
		}
}
