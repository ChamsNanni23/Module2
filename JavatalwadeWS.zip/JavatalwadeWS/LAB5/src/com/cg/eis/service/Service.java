package com.cg.eis.service;

public class Service implements EmployeeService
{
	private float empSal;
	private String designation;
	
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Service(float empSal, String designation) {
		super();
		this.empSal = empSal;
		this.designation = designation;
	}
	public Service() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Service [empSal=" + empSal + ", designation=" + designation
				+ "]";
	}
	@Override
	public String insuranceScheme()
	{
		
		if((empSal>5000 && empSal<20000) && (designation.compareTo("System Associate")==0))
		{
			return "Scheme C";
		}
		else if((empSal>=20000 && empSal<40000) && (designation.compareTo("Programmer")==0))
		{
			return "Scheme B";
		}
		else if((empSal>=40000) && (designation.compareTo("Manager")==0))
		{
			return "Scheme A";
		}
		else 
		{
			return "No scheme";
			
		}
	}
}


