package com.cg.mob.bean;

public class Purchase {
	
		private String name;
		private String mailId;
		private String mobileNo;
		private int mobileId;
		private int purhcaseId;
		private String purchaseDate;
		
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMailId() {
			return mailId;
		}
		public void setMailId(String mailId) {
			this.mailId = mailId;
		}
		public String getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}
		public int getMobileId() {
			return mobileId;
		}
		public void setMobileId(int mobileId) {
			this.mobileId = mobileId;
		}
		public int getPurhcaseId() {
			return purhcaseId;
		}
		public void setPurhcaseId(int purhcaseId) {
			this.purhcaseId = purhcaseId;
		}
		public String getPurchaseDate() {
			return purchaseDate;
		}
		public void setPurchaseDate(String purchaseDate) {
			this.purchaseDate = purchaseDate;
		}
		public Purchase(String name, String mailId, String mobileNo,
				int mobileId, int purhcaseId, String purchaseDate) {
			super();
			this.name = name;
			this.mailId = mailId;
			this.mobileNo = mobileNo;
			this.mobileId = mobileId;
			this.purhcaseId = purhcaseId;
			this.purchaseDate = purchaseDate;
		}
		public Purchase() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "CustomerBean [name=" + name + ", mailId=" + mailId
					+ ", mobileNo=" + mobileNo + ", mobileId=" + mobileId
					+ ", purhcaseId=" + purhcaseId + ", purchaseDate="
					+ purchaseDate + "]";
		}
		
		
		
}
