package com.cg.mob.exception;

public class MobilePurchaseException extends Exception 
{

	private static final long serialVersionUID = -3711984272849461979L;

	public  MobilePurchaseException(String msg)
	{
		super(msg);
	}

}
