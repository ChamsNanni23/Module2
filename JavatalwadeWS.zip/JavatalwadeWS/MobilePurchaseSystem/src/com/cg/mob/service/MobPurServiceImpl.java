package com.cg.mob.service;


import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.Purchase;
import com.cg.mob.dao.MobDao;
import com.cg.mob.dao.MobDaoImpl;
import com.cg.mob.exception.MobilePurchaseException;

public class MobPurServiceImpl implements MobPurService {

    MobDao mobDao = null;

    public MobPurServiceImpl() {
        super();
        mobDao = new MobDaoImpl();
    }

    @Override
    public int addMob(Mobile mob) throws MobilePurchaseException {

        return mobDao.addMob(mob);
    }

    @Override
    public int addPurDetails(Purchase pur,Mobile mob) throws MobilePurchaseException {

        return mobDao.addPurDetails(pur,mob);
    }

    @Override
    public int generatePurId() throws MobilePurchaseException {

        return mobDao.generatePurId();
    }

    @Override
    public boolean validatephoneno(String custPhoneNo) throws MobileException {
        String numPattern = "[0-9]{10}";
        if(Pattern.matches(numPattern, custPhoneNo))
        {
            return true;
        }
        else
        {
            throw new MobilePurchaseException("Only 10 digits allowed in customer phone number.");
        }
    }

    @Override
    public boolean validatePurName(String name) throws MobilePurchaseException {
        String namePattern = "[A-Z][a-z]{1,19}";
        if(Pattern.matches(namePattern, name))
        {
            return true;
        }
        else
        {
            throw new MobileException("Only Chars Allowed and "
                    + "starts with Capital e.g Babitha.");
        }
    }

    @Override
    public boolean validatePurEmail(String custEmail) throws MobileException {
        //String namePattern = "\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
        String namePattern = "^(.+)@(.+)$";
        if(Pattern.matches(namePattern, custEmail))
        {
            return true;
        }
        else
        {
            throw new MobileException("Invalid Email Id ...eg: xyz@gmail.com");
        }
    }

    @Override
    public boolean validateMobId(int mobId) throws MobileException {
        String pattern = "[1][0-9]{3}";
        int flag=0;
        if(Pattern.matches(pattern, new Integer(mobId).toString()))
        {

            ArrayList<Integer> mobList = mobDao.getAllMobId();
            for(int temp:mobList)
            {
                if(mobId == temp)
                {
                    flag=1;
                }
            }
        }
        if(flag==1)
        {
            return true;
        }
        else
        {
            throw new MobileException("Invalid MobId...");
        }
    }

    @Override
    public boolean validateMobQuan(Mobiles mob) throws MobileException {
        
        if((mobDao.getMobQuan(mob)-mob.getMobileQuantity())>0)
        {
            return true;
        }
        else 
        {
            throw new MobileException("Available Mobile Quantity is zero...");
        }
    }

    @Override
    public ArrayList<Mobiles> getAllMob() throws MobileException {
        
        return mobDao.getAllMob();
    }

    @Override
    public int deleteMobDetails(Mobiles mob) throws MobileException {
        
        return mobDao.deleteMobDetails(mob);
    }

    @Override
    public ArrayList<Mobiles> searchMob(float minValue, float maxValue)
            throws MobileException {
        
        return mobDao.searchMob(minValue, maxValue);
    }

    @Override
    public int updateMob(Mobiles mob) throws MobileException {
        
        return mobDao.updateMob(mob);
    }
}