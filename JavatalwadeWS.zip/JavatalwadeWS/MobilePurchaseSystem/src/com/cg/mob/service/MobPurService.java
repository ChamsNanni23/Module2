package com.cg.mob.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.mob.bean.Purchase;
import com.cg.mob.bean.Mobile;
import com.cg.mob.exception.MobilePurchaseException;

public interface MobPurService
{
		public List<Mobile> pricedMobileDetails(int minprice, int maxprice) throws MobilePurchaseException;
		public int addPurchaseDetails(Purchase pur) throws MobilePurchaseException;
		public boolean validatename(String name)  throws MobilePurchaseException;
		public boolean validatemailid(String mail) throws MobilePurchaseException;
		public boolean validatephoneno(String phoneno) throws MobilePurchaseException;
		public boolean validatemobileid(int mobileid) throws MobilePurchaseException;
		public ArrayList<Mobile> searchMob(float minPrice, float maxPrice) throws MobilePurchaseException;
		public int deleteMobDetails(Mobile m) throws MobilePurchaseException;
		public ArrayList<Mobile> getAll() throws MobilePurchaseException;
		public boolean validateMobQuan(Mobile m) throws MobilePurchaseException;
		public int updateMob(Mobile m) throws MobilePurchaseException;
		public int addPurDetails(Purchase pd, Mobile m);
		int addMob(Mobile mob) throws MobilePurchaseException;
		int generatePurId() throws MobilePurchaseException;
		public boolean validatePurName(String name) throws MobilePurchaseException;
		
 
}
