package com.cg.mob.dao;

import java.util.List;

import com.cg.mob.bean.Purchase;
import com.cg.mob.bean.Mobile;
import com.cg.mob.exception.MobilePurchaseException;

public interface MobDao {

		public List<Mobile> showAllMobileDetails() throws MobilePurchaseException;
		public Mobile deleteMobileById(int id) throws MobilePurchaseException;
		public List<Mobile> pricedMobileDetails(int minprice, int maxprice) throws MobilePurchaseException;
		public int addPurchaseDetails(Purchase pur) throws MobilePurchaseException;
		public int addMob(Mobile mob) throws MobilePurchaseException;
		public int addPurDetails(Purchase pur, Mobile mob) throws MobilePurchaseException;
			
}
