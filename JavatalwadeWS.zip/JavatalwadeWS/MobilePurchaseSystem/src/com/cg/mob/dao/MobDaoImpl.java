package com.cg.mob.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.mob.bean.Purchase;
import com.cg.mob.bean.Mobile;
import com.cg.mob.exception.MobilePurchaseException;
import com.cg.mob.util.DBUtil;

public class MobDaoImpl implements MobDao
{
	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    @Override
	public List<Mobile> showAllMobileDetails() throws MobilePurchaseException 
	{
		List<Mobile> moblist=new ArrayList<Mobile>();
		String selectQry="SELECT * FROM mobiles";
		Mobile mb=null;
		try {
			 con=DBUtil.getCon();
			 st=con.createStatement();
			 rs=st.executeQuery(selectQry);
			 while(rs.next())
			{
				Mobile mob=new Mobile();
				mob.setMobileId(rs.getInt("mobileid"));
				mob.setMobileName(rs.getString("name"));
				mob.setMobilePrice(rs.getDouble("price"));
				mob.setMobileQuantity(rs.getInt("quantity"));
				moblist.add(mob);
			}
		} 
		catch (Exception e) 
		{
			throw new MobilePurchaseException("EXCEPTION IN DISPLAYING RECORDS"+ e.getMessage());
		}
		finally
		{
			try {
				rs.close();
				st.close();
				con.close();
			    } 
			catch (SQLException e)
			{
				throw new MobilePurchaseException(e.getMessage());
			}
		}
		return moblist;
	}

	@Override
	public Mobile deleteMobileById(int id) throws MobilePurchaseException
	{
		Mobile mob=new Mobile();
		try {
			 con=DBUtil.getCon();
			String qry="Delete from mobiles where mobileid=?";
			String updateQry="Update purchasedetails set mobileid=null where mobileid=?";
			String findQry="Select mobileid,name,price,quantity from mobiles where mobileid=?";
			PreparedStatement pre=con.prepareStatement(findQry);
			PreparedStatement pstmt=con.prepareStatement(qry);
			PreparedStatement pupdate=con.prepareStatement(updateQry);
			pstmt.setInt(1, id);
			pupdate.setInt(1, id);
			pre.setInt(1, id);
			ResultSet rs=pre.executeQuery();
			if(rs.next())
			{
				mob.setMobileId(rs.getInt("mobileid"));
				mob.setMobileName(rs.getString("name"));
				mob.setMobilePrice(rs.getDouble("price"));
				mob.setMobileQuantity(rs.getInt("quantity"));
				pupdate.executeUpdate();
				pstmt.executeUpdate();
				return mob;
			}
			else
			{
				return null;		
			}
		}
		catch (SQLException | IOException e) 
		{
			throw new MobilePurchaseException("EXCEPTION IN DISPAYING RECORD"+ e.getMessage());
		}
	}

	@Override
	public List<Mobile> pricedMobileDetails(int minprice, int maxprice) throws MobilePurchaseException
	{
		List<Mobile> mylist=new ArrayList<Mobile>();
		
		try {
			 con=DBUtil.getCon();
			String qry="select mobileid,name,price,quantity from mobiles where price>=? and price<=?";
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setInt(1, minprice);
			pstmt.setInt(2, maxprice);
			ResultSet rst=pstmt.executeQuery();
			while(rst.next())
			{
				
				Mobile mob=new Mobile();
				mob.setMobileId(rst.getInt("mobileid"));
				mob.setMobileName(rst.getString("name"));
				mob.setMobilePrice(rst.getDouble("price"));
				mob.setMobileQuantity(rst.getInt("quantity"));
				mylist.add(mob);
			}
			con.close();
		}
		catch (SQLException | IOException e) 
		{
			throw new MobilePurchaseException("EXCEPTION IN DISPLAYING RECORDS"+ e.getMessage());
		}
		return mylist;
	}

	@Override
	public int addPurchaseDetails(Purchase pur) throws MobilePurchaseException
	{
		int purchaseid;
		
		try {
			purchaseid = 0;
			con=DBUtil.getCon();
			String qry="Insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values(purchaseid_seq.nextval,?,?,?,sysdate,?)";
			String updateQry="Update mobiles set quantity=quantity-1 where mobileid=?";
			PreparedStatement pstmt=con.prepareStatement(qry);
			PreparedStatement pstmt2=con.prepareStatement(updateQry);
			pstmt.setString(1, pur.getName());
			pstmt.setString(2, pur.getMailId());
			pstmt.setString(3, pur.getMobileNo());
			pstmt.setInt   (4, pur.getMobileId());
			pstmt2.setInt  (1, pur.getMobileId());
			int count=pstmt.executeUpdate();
			
			if(count<=0)
			{
				throw new MobilePurchaseException("INSERTION FAIL");
			}
			qry="Select purchaseid_seq.currval from dual";
			pstmt=con.prepareStatement(qry);
			ResultSet rst=pstmt.executeQuery();
			if(rst.next())
			{
				purchaseid=rst.getInt(1);
				pstmt2.executeUpdate();
			}
			else
			{
				throw new MobilePurchaseException("SEQUENCE NOT FOUND OR UNABLE TO GET VALUE FROM SEQUENCE");
			}
			con.close();
		}
		catch (SQLException | IOException e) 
		{
		   throw new MobilePurchaseException("EXCEPTION IN ADDING "+e.getMessage());
		}
		return purchaseid;
	}
}