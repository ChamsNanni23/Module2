package com.cg.mob.ui;

import java.util.ArrayList;
import java.util.Scanner;


import com.cg.mob.bean.Mobile;
import com.cg.mob.bean.Purchase;
import com.cg.mob.exception.MobilePurchaseException;
import com.cg.mob.service.MobPurService;
import com.cg.mob.service.MobPurServiceImpl;

public class MobileClient {
    static Scanner sc = null;
    static MobPurService mobSer = null;

    public static void main(String[] args) {
        sc = new Scanner(System.in);
        mobSer = new MobPurServiceImpl();
        int choice = 0;
        while(true)
        {
            System.out.println("\nWhat Do u want to Do ? ");
            System.out.println("\n1:Insert the customer and purchase details and "
                    + "Update the mobile quantity in mobiles table\n"
                    + " 2:View details of all mobiles available in the shop"
                    + "\n 3:Delete a mobile details based on mobile id\n "
                    + "4:Search mobiles based on price range\n 5:Exit");

            choice = sc.nextInt();
            switch(choice)
            {
            case 1: insertDetails();
            break;
            case 2: selectMobileDetails();
            break;
            case 3: deleteMobDetails();
            break;
            case 4: searchMobDetails();
            break;
            default:System.exit(0);
            }
        }
    }
    /*Main ends here ***********************/

    public static void searchMobDetails()
    {
        System.out.println("Enter Min Price Range of Mobile: ");
        float minPrice = sc.nextFloat();
        System.out.println("Enter Max Price Range of Mobile: ");
        float maxPrice = sc.nextFloat();
        try 
        {

            ArrayList<Mobile> mobList = mobSer.searchMob(minPrice, maxPrice);

            for(Mobile m:mobList)
            {
                System.out.println(m);
            }
        } 
        catch (MobilePurchaseException e)
        {
            System.out.println("Some exception while fetching data");
            e.printStackTrace();
        }
    }


    public static void deleteMobDetails()
    {
        System.out.println("Enter Mobile Id: ");
        int mobId = sc.nextInt();
        try
        {
            if(mobSer.validatemobileid(mobId))
            {
                Mobile m = new Mobile();
                m.setMobileId(mobId);
                int dataDeleted = mobSer.deleteMobDetails(m);
                if(dataDeleted==1)
                {
                    System.out.println("Mobile Details Deleted...");
                }
                else 
                {
                    System.out.println("May raise some exception while addition");
                }
            }
        }
        catch (MobilePurchaseException e) 
        {
            System.out.println(e.getMessage());
        }
    }

    public static void selectMobileDetails() {

        try 
        {
            ArrayList<Mobile> mobList = mobSer.getAll();

            for(Mobile m:mobList)
            {
                System.out.println(m);
            }
        } 
        catch (MobilePurchaseException e)
        {
            System.out.println("Some exception while fetching data");
            e.printStackTrace();
        }

    }

    public static void insertDetails(){
        System.out.println("Enter Customer name: ");
        String custName = sc.next();
        try 
        {
            if(mobSer.validatename(custName))
            {
                System.out.println("Enter Cutomer EmailId: ");
                String custEmail = sc.next();
                if(mobSer.validatemailid(custEmail))
                {
                    System.out.println("Enter Customer Phone no: ");
                    String custPhoneNo =sc.next();
                    if(mobSer.validatephoneno(custPhoneNo))
                    {
                        System.out.println("Enter Mobile Id: ");
                        int mobId =sc.nextInt();
                        if(mobSer.validatemobileid(mobId))
                        {
                            Mobile m = new Mobile();
                            m.setMobileId(mobId);
                            System.out.println("Enter Quantity of mobile purchased: ");
                            int mobQuan =sc.nextInt();
                            m.setMobileQuantity(mobQuan);
                            if(mobSer.validateMobQuan(m) && mobQuan>0)
                            {
                            
                            if(mobSer.updateMob(m)>0)
                            {
                                Purchase pd = new Purchase();

                                pd.setName(custName);
                                pd.setMailId(custEmail);
                                pd.setMobileNo(custPhoneNo);
                                
                                int dataAdded = mobSer.addPurDetails(pd,m);

                                if(dataAdded==1)
                                {
                                    System.out.println("Purchase Details Added...");
                                }
                                else 
                                {
                                    System.out.println("May raise some exception while addition");
                                }   
                            }
                            else
                            {
                                System.out.println("Could not update mobile quantity");
                            }
                        }
                            else
                            {
                                System.out.println("Mobile not available.");
                            }
                    }
                }
            }
            } 
        }
        catch (MobilePurchaseException e) 
        {
            System.out.println(e.getMessage());
        }
    }
}
